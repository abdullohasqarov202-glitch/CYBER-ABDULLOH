# CYBER ABDULLOH Portfolio

Railway uchun tayyor PHP portfolio.

## Railway
PHP fayllari repository rootida turadi. Railway PHP loyihani avtomatik aniqlaydi.

## Muhim
Rasmlar Unsplash CDN orqali yuklanadi, shuning uchun sayt internetga chiqqanda rasmlar ko‘rinadi.
